def title_rus():
	return "rus"


def title_eng():
	return "eng"


def year():
	return 0
