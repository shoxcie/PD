class Example:
	def greeting(self):
		print("Hello, World!")
